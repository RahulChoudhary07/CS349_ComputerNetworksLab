To run the code:
Copy the two files (group4_main.cc and group4_header.h) in the scratch folder of ns3.
Run the following command from just outside the scratch folde:

./waf --run scratch/group4_main

It will generate .plt files for all the graphs on which the following command will give the corresponding .png file of the graph:
gnuplot <FileName>